const crypto = require('crypto');

const MERCHANT_ID = process.env.ECPAY_MERCHANT_ID;
const HASH_KEY = process.env.ECPAY_HASH_KEY;
const HASH_IV = process.env.ECPAY_HASH_IV;
const API_URL = process.env.ECPAY_API_URL;

/**
 * 綠界專用的 URL encode
 * 綠界要求把某些字元轉小寫，跟標準 encodeURIComponent 不太一樣
 */
function ecpayUrlEncode(str) {
  return encodeURIComponent(str)
    .replace(/%20/g, '+')
    .replace(/!/g, '%21')
    .replace(/\*/g, '%2a')
    .replace(/\(/g, '%28')
    .replace(/\)/g, '%29')
    .toLowerCase()
    .replace(/%2d/g, '-')
    .replace(/%5f/g, '_')
    .replace(/%2e/g, '.')
    .replace(/%21/g, '!')
    .replace(/%2a/g, '*')
    .replace(/%28/g, '(')
    .replace(/%29/g, ')');
}

/**
 * 產生 CheckMacValue (綠界檢查碼)
 */
function generateCheckMacValue(params) {
  // 1. 依照英文字母順序排序
  const sortedKeys = Object.keys(params).sort((a, b) =>
    a.toLowerCase().localeCompare(b.toLowerCase())
  );

  // 2. 組成 query string
  let queryString = sortedKeys
    .map(key => `${key}=${params[key]}`)
    .join('&');

  // 3. 前後加上 HashKey 和 HashIV
  queryString = `HashKey=${HASH_KEY}&${queryString}&HashIV=${HASH_IV}`;

  // 4. URL encode 並轉小寫
  queryString = ecpayUrlEncode(queryString);

  // 5. SHA256 後轉大寫
  return crypto.createHash('sha256').update(queryString).digest('hex').toUpperCase();
}

/**
 * 產生綠界付款表單參數
 */
function createPaymentParams({ orderNo, amount, itemName, baseUrl }) {
  // 綠界要的時間格式: yyyy/MM/dd HH:mm:ss
  const now = new Date();
  const tradeDate = now.toLocaleString('zh-TW', {
    timeZone: 'Asia/Taipei',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false
  }).replace(/-/g, '/');

  const params = {
    MerchantID: MERCHANT_ID,
    MerchantTradeNo: orderNo,
    MerchantTradeDate: tradeDate,
    PaymentType: 'aio',
    TotalAmount: amount,
    TradeDesc: 'LINE 訂單',
    ItemName: itemName,
    ReturnURL: `${baseUrl}/api/ecpay/notify`,
    ClientBackURL: `${baseUrl}/payment-result?order=${orderNo}`,
    OrderResultURL: `${baseUrl}/payment-result?order=${orderNo}`,
    ChoosePayment: 'ALL',
    EncryptType: 1
  };

  params.CheckMacValue = generateCheckMacValue(params);
  return params;
}

/**
 * 驗證綠界回傳的 CheckMacValue
 */
function verifyCheckMacValue(receivedParams) {
  const { CheckMacValue, ...params } = receivedParams;
  const calculated = generateCheckMacValue(params);
  return calculated === CheckMacValue;
}

/**
 * 產生綠界付款的 HTML 表單 (自動 submit)
 */
function generatePaymentForm(params) {
  const inputs = Object.entries(params)
    .map(([k, v]) => `<input type="hidden" name="${k}" value="${v}" />`)
    .join('\n');

  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>跳轉至綠界付款</title>
</head>
<body>
  <p style="text-align:center;padding-top:50px;font-family:sans-serif;">
    正在跳轉至付款頁面...
  </p>
  <form id="ecpay-form" action="${API_URL}" method="POST">
    ${inputs}
  </form>
  <script>
    document.getElementById('ecpay-form').submit();
  </script>
</body>
</html>`;
}

module.exports = {
  createPaymentParams,
  verifyCheckMacValue,
  generatePaymentForm
};
