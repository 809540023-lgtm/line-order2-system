require('dotenv').config();
const express = require('express');
const path = require('path');
const line = require('@line/bot-sdk');
const db = require('./db');
const ecpay = require('./ecpay');

const app = express();
const PORT = process.env.PORT || 3000;
const BASE_URL = process.env.BASE_URL || `http://localhost:${PORT}`;

// LINE Bot 設定
const lineConfig = {
  channelAccessToken: process.env.LINE_CHANNEL_ACCESS_TOKEN,
  channelSecret: process.env.LINE_CHANNEL_SECRET
};
const lineClient = new line.Client(lineConfig);

// 靜態檔案
app.use(express.static(path.join(__dirname, '..', 'public')));

// 提供 LIFF ID 給前端
app.get('/api/config', (req, res) => {
  res.json({ liffId: process.env.LIFF_ID });
});

// LINE Webhook (顧客傳訊息給 OA 時觸發)
app.post('/webhook', line.middleware(lineConfig), async (req, res) => {
  try {
    const events = req.body.events;
    await Promise.all(events.map(async (event) => {
      if (event.type !== 'message' || event.message.type !== 'text') return;

      const text = event.message.text.trim();
      const liffUrl = `https://liff.line.me/${process.env.LIFF_ID}`;

      // 關鍵字觸發下單連結
      const triggers = ['下單', '購買', '訂購', '我要買', '商品', '菜單', 'order'];
      if (triggers.some(k => text.toLowerCase().includes(k.toLowerCase()))) {
        await lineClient.replyMessage(event.replyToken, {
          type: 'template',
          altText: '點此前往下單',
          template: {
            type: 'buttons',
            text: '👋 歡迎！點下方按鈕直接下單',
            actions: [
              { type: 'uri', label: '🛒 立即下單', uri: liffUrl }
            ]
          }
        });
      } else if (text === '訂單查詢' || text === '我的訂單') {
        await lineClient.replyMessage(event.replyToken, {
          type: 'text',
          text: '請告知你的訂單編號（OD開頭），我會幫你查詢～'
        });
      }
    }));
    res.status(200).end();
  } catch (err) {
    console.error('Webhook 錯誤:', err);
    res.status(200).end(); // 回 200 避免 LINE 重送
  }
});

// 取得商品列表
app.get('/api/products', (req, res) => {
  const products = db.prepare(
    'SELECT * FROM products WHERE is_active = 1 ORDER BY id'
  ).all();
  res.json(products);
});

// 建立訂單 + 跳轉到綠界
app.post('/api/orders', express.json(), (req, res) => {
  try {
    const {
      lineUserId,
      lineDisplayName,
      customerName,
      customerPhone,
      customerAddress,
      items, // [{productId, quantity}]
      note
    } = req.body;

    // 驗證資料
    if (!lineUserId || !customerName || !customerPhone || !customerAddress || !items?.length) {
      return res.status(400).json({ error: '資料不完整' });
    }

    // 計算總金額 + 組商品名稱
    let totalAmount = 0;
    const itemDetails = [];
    const itemNames = [];

    for (const item of items) {
      const product = db.prepare('SELECT * FROM products WHERE id = ?').get(item.productId);
      if (!product) return res.status(400).json({ error: `商品 ${item.productId} 不存在` });
      const subtotal = product.price * item.quantity;
      totalAmount += subtotal;
      itemDetails.push({
        id: product.id,
        name: product.name,
        price: product.price,
        quantity: item.quantity,
        subtotal
      });
      itemNames.push(`${product.name} x${item.quantity}`);
    }

    // 產生訂單編號 (時間戳)
    const orderNo = `OD${Date.now()}`;

    // 寫入資料庫
    db.prepare(`
      INSERT INTO orders (
        order_no, line_user_id, line_display_name,
        customer_name, customer_phone, customer_address,
        items, total_amount, note
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      orderNo,
      lineUserId,
      lineDisplayName || '',
      customerName,
      customerPhone,
      customerAddress,
      JSON.stringify(itemDetails),
      totalAmount,
      note || ''
    );

    // 產生綠界付款表單
    const ecpayParams = ecpay.createPaymentParams({
      orderNo,
      amount: totalAmount,
      itemName: itemNames.join('#').substring(0, 200), // 綠界限制 200 字
      baseUrl: BASE_URL
    });

    res.json({
      success: true,
      orderNo,
      paymentForm: ecpay.generatePaymentForm(ecpayParams)
    });

  } catch (err) {
    console.error('建立訂單失敗:', err);
    res.status(500).json({ error: '建立訂單失敗' });
  }
});

// 綠界付款結果通知 (Server to Server)
app.post('/api/ecpay/notify',
  express.urlencoded({ extended: false }),
  async (req, res) => {
    try {
      console.log('綠界 webhook 收到:', req.body);

      // 驗證 CheckMacValue
      if (!ecpay.verifyCheckMacValue(req.body)) {
        console.error('CheckMacValue 驗證失敗');
        return res.send('0|CheckMacValue Error');
      }

      const { MerchantTradeNo, RtnCode, TradeNo, PaymentType, PaymentDate } = req.body;

      if (RtnCode === '1' || RtnCode === 1) {
        // 付款成功
        const order = db.prepare('SELECT * FROM orders WHERE order_no = ?').get(MerchantTradeNo);
        if (order) {
          db.prepare(`
            UPDATE orders
            SET payment_status = 'paid',
                ecpay_trade_no = ?,
                payment_type = ?,
                paid_at = ?
            WHERE order_no = ?
          `).run(TradeNo, PaymentType, PaymentDate, MerchantTradeNo);

          // 推送 LINE 訊息給顧客
          try {
            await lineClient.pushMessage(order.line_user_id, {
              type: 'text',
              text: `✅ 付款成功！\n\n訂單編號: ${MerchantTradeNo}\n金額: NT$ ${order.total_amount}\n\n我們會盡快為你出貨，謝謝！`
            });
          } catch (e) {
            console.error('推送 LINE 訊息失敗:', e.message);
          }
        }
      }

      // 必須回 1|OK 給綠界
      res.send('1|OK');
    } catch (err) {
      console.error('處理綠界通知失敗:', err);
      res.send('0|Error');
    }
  }
);

// 付款結果頁面 (使用者付完款看到的頁面)
app.get('/payment-result', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'result.html'));
});

// 取得訂單狀態
app.get('/api/orders/:orderNo', (req, res) => {
  const order = db.prepare('SELECT * FROM orders WHERE order_no = ?').get(req.params.orderNo);
  if (!order) return res.status(404).json({ error: '訂單不存在' });
  res.json(order);
});

// === 簡易後台 (你自己看訂單用) ===
// 列出所有訂單
app.get('/admin/orders', (req, res) => {
  const orders = db.prepare('SELECT * FROM orders ORDER BY created_at DESC LIMIT 100').all();
  res.json(orders);
});

// 標記訂單已出貨 + 通知顧客
app.post('/admin/orders/:orderNo/ship', async (req, res) => {
  const orderNo = req.params.orderNo;
  const order = db.prepare('SELECT * FROM orders WHERE order_no = ?').get(orderNo);
  if (!order) return res.status(404).json({ error: '訂單不存在' });

  db.prepare(`
    UPDATE orders SET shipping_status = 'shipped' WHERE order_no = ?
  `).run(orderNo);

  // 推送 LINE 通知
  try {
    await lineClient.pushMessage(order.line_user_id, {
      type: 'text',
      text: `📦 你的訂單已出貨！\n\n訂單編號: ${orderNo}\n\n如有任何問題，歡迎直接回覆此訊息詢問。`
    });
  } catch (e) {
    console.error('推送出貨通知失敗:', e.message);
  }

  res.json({ success: true });
});

// 健康檢查 (Render 會用)
app.get('/health', (req, res) => res.send('OK'));

app.listen(PORT, () => {
  console.log(`🚀 伺服器啟動於 ${BASE_URL}`);
  console.log(`📦 LIFF 入口: ${BASE_URL}/`);
  console.log(`👀 訂單後台: ${BASE_URL}/admin.html`);
});
