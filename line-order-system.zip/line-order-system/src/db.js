const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, '..', 'orders.db'));

// 建立資料表
db.exec(`
  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    price INTEGER NOT NULL,
    image_url TEXT,
    stock INTEGER DEFAULT 0,
    description TEXT,
    is_active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_no TEXT UNIQUE NOT NULL,
    line_user_id TEXT NOT NULL,
    line_display_name TEXT,
    customer_name TEXT NOT NULL,
    customer_phone TEXT NOT NULL,
    customer_address TEXT NOT NULL,
    items TEXT NOT NULL,
    total_amount INTEGER NOT NULL,
    payment_status TEXT DEFAULT 'pending',
    shipping_status TEXT DEFAULT 'pending',
    ecpay_trade_no TEXT,
    payment_type TEXT,
    paid_at DATETIME,
    note TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(line_user_id);
  CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(payment_status);
`);

// 如果是空的，塞兩筆範例商品
const count = db.prepare('SELECT COUNT(*) as c FROM products').get().c;
if (count === 0) {
  const insert = db.prepare(`
    INSERT INTO products (name, price, image_url, stock, description)
    VALUES (?, ?, ?, ?, ?)
  `);
  insert.run('範例商品 A', 350, 'https://placehold.co/400x400/png?text=Product+A', 100, '這是商品 A 的說明');
  insert.run('範例商品 B', 580, 'https://placehold.co/400x400/png?text=Product+B', 50, '這是商品 B 的說明');
  console.log('✅ 已建立範例商品');
}

module.exports = db;
